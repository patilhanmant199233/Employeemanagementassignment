﻿namespace EmployeeManagement.Model
{
    public class Employee
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LaststName { get; set; }
        public string Department { get; set; }
        public string Email { get; set; }
        public int Salary { get; set; }
        public DateTime JoiningDate { get; set; }
    }
}
